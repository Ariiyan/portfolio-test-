import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Ariyan Ahmed — Designer, Developer & Digital Creator",
  description: "A multidisciplinary portfolio spanning games, digital products, interactive experiences and technology.",
  metadataBase: new URL("https://ariyanahmed.com"),
  openGraph: {
    title: "Ariyan Ahmed — Designer, Developer & Digital Creator",
    description: "I build immersive experiences and useful technology.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
