"use client";

import { useEffect, useState } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import {
  ArrowDown, ArrowDownRight, ArrowRight, ArrowUpRight, Asterisk, Braces,
  Check, ChevronDown, Code2, Cpu, ExternalLink, Gamepad2, Github, Layers3,
  Mail, Menu, Monitor, MousePointer2, Radio, Sparkles, X, Zap
} from "lucide-react";

type Project = {
  number: string; title: string; type: string; summary: string; tags: string[];
  category: string; visual: string; status: string; role: string; challenge: string;
  approach: string; outcome: string;
};

const projects: Project[] = [
  {
    number: "01", title: "H-7 Sentinel", type: "Custom WebGL experience",
    summary: "A browser-based interactive experience exploring atmosphere, motion and real-time 3D.",
    tags: ["WebGL", "Three.js", "Interactive"], category: "Interactive",
    visual: "sentinel", status: "Selected work",
    role: "Concept, interaction design and development",
    challenge: "Create an experience that feels closer to an explorable game world than a conventional webpage.",
    approach: "A real-time 3D direction with a focus on atmosphere, purposeful camera movement and interaction-led storytelling.",
    outcome: "A portfolio project demonstrating the intersection of creative direction and browser-based 3D. Add final performance figures and a live build link when available."
  },
  {
    number: "02", title: "Scrypted Dreams", type: "WordPress website",
    summary: "A visual web experience with a distinct identity, structured content and responsive presentation.",
    tags: ["WordPress", "Web Design", "UI/UX"], category: "Web",
    visual: "dreams", status: "Website",
    role: "Web design and development",
    challenge: "Translate a creative concept into a coherent digital presence that is easy to explore on different screen sizes.",
    approach: "Designed the information hierarchy and page composition, then implemented the site with responsive layouts and a content-managed workflow.",
    outcome: "A web project demonstrating brand expression and practical implementation. Insert the verified live URL and project screenshots."
  },
  {
    number: "03", title: "Artemis", type: "VR FPS UI · Titania",
    summary: "A first-person VR interface concept designed around spatial awareness and player readability.",
    tags: ["Unity", "VR", "UI/UX"], category: "Games",
    visual: "artemis", status: "Game interface",
    role: "UI design and interaction exploration",
    challenge: "Make essential game information readable without overwhelming the player or breaking immersion.",
    approach: "Explored a hierarchy of diegetic and conventional UI patterns, considering placement, glanceability and comfort in a VR context.",
    outcome: "A game UI project that supports a wider interest in human-computer interaction and immersive design. Add gameplay captures and implementation details."
  },
  {
    number: "04", title: "Time Loop Assassins", type: "Game design project",
    summary: "A time-loop game concept exploring replay, adaptive challenge and player decision-making.",
    tags: ["Game Design", "Unity", "C#"], category: "Games",
    visual: "loop", status: "Game systems",
    role: "Game design and development",
    challenge: "Use repetition as a meaningful mechanic rather than simply replaying the same sequence.",
    approach: "Explored gameplay systems and dynamic difficulty adjustment to shape how repeated attempts can feel different.",
    outcome: "A systems-focused game project. Add a playable build, development timeline and validated results when ready."
  },
  {
    number: "05", title: "Mintly Pay", type: "Digital payment product",
    summary: "A digital product concept focused on making payment flows and financial information easier to navigate.",
    tags: ["Product Design", "Web UI", "Fintech"], category: "Products",
    visual: "mintly", status: "Digital product",
    role: "Website and product presentation",
    challenge: "Present a service clearly, build trust and make the next action obvious to potential customers.",
    approach: "A conversion-aware web direction with clear page hierarchy, focused messaging and responsive product presentation.",
    outcome: "A digital product/web project. Add verified product screens, live links and real conversion metrics when available."
  },
  {
    number: "06", title: "PC Build & Systems", type: "Hardware / workstation",
    summary: "A high-performance PC build combining component selection, system configuration and hands-on troubleshooting.",
    tags: ["Hardware", "Windows", "Systems"], category: "Hardware",
    visual: "hardware", status: "Hardware lab",
    role: "Component research, assembly and configuration",
    challenge: "Balance performance, thermal behaviour, component compatibility and a clean, quiet workstation experience.",
    approach: "Considered platform compatibility, cooling layout, firmware configuration, storage and display connectivity as one system.",
    outcome: "A hands-on hardware project that extends the portfolio beyond software. Add your own build photos and final benchmark data."
  },
];

const skills = [
  { icon: Gamepad2, title: "Game development", subtitle: "Worlds, systems & play", items: ["Unity", "Unreal Engine", "C#", "Blueprints", "Game systems", "DDA"] },
  { icon: Code2, title: "Web engineering", subtitle: "Products built for the web", items: ["JavaScript / TypeScript", "React / Next.js", "HTML / CSS", "Tailwind CSS", "WordPress / Webflow", "REST APIs"] },
  { icon: Layers3, title: "Design & experience", subtitle: "Interfaces with intent", items: ["Figma", "UI / UX", "Prototyping", "Motion design", "Design systems", "Visual storytelling"] },
  { icon: Radio, title: "Immersive technology", subtitle: "Beyond the flat screen", items: ["WebXR / OpenXR", "Meta XR", "ARKit / ARCore", "VR interface design", "3D interaction", "Blender"] },
  { icon: Cpu, title: "Hardware & systems", subtitle: "Curiosity at every layer", items: ["PC building", "Windows / Linux", "Troubleshooting", "Networking", "Peripherals", "System optimisation"] },
];

const filters = ["All", "Games", "Web", "Interactive", "Products", "Hardware"];

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return <motion.div className={className} initial={{ opacity: 0, y: 26 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.12 }} transition={{ duration: .7, delay, ease: [0.22, 1, 0.36, 1] }}>{children}</motion.div>;
}

function ProjectVisual({ kind }: { kind: string }) {
  return <div className={`project-visual visual-${kind}`}>
    <div className="visual-grid" />
    {kind === "sentinel" && <><div className="planet" /><div className="orbit orbit-a" /><div className="orbit orbit-b" /><div className="silhouette"><span /></div><div className="visual-label">SECTOR 07 <b>·</b> LIVE ENVIRONMENT</div></>}
    {kind === "dreams" && <><div className="dream-sun" /><div className="dream-mountain m1" /><div className="dream-mountain m2" /><div className="dream-mountain m3" /><div className="visual-label">SCRYPTED / DREAMS</div></>}
    {kind === "artemis" && <><div className="helmet"><div className="helmet-glass" /></div><div className="hud hud-one">VITALS <b>98%</b></div><div className="hud hud-two">SYSTEM READY <i /></div><div className="visual-label">ARTEMIS — IMMERSIVE UI</div></>}
    {kind === "loop" && <><div className="loop-ring r1" /><div className="loop-ring r2" /><div className="loop-ring r3" /><div className="loop-core">RE<br/>:TRY</div><div className="visual-label">TIME LOOP / ITERATION 04</div></>}
    {kind === "mintly" && <><div className="app-window"><div className="app-top"><i/><i/><i/></div><div className="app-balance">Available balance <b>£8,420.50</b></div><div className="app-chart"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="app-pills"><i/><i/><i/></div></div><div className="visual-label">MINTLY / PRODUCT EXPLORATION</div></>}
    {kind === "hardware" && <><div className="pc-case"><div className="pc-fan f1"/><div className="pc-fan f2"/><div className="pc-fan f3"/><div className="pc-board"/></div><div className="visual-label">SYSTEM / BUILD 001</div></>}
    <span className="visual-index">AA / {kind.toUpperCase()}</span>
  </div>;
}

export default function Home() {
  const [activeFilter, setActiveFilter] = useState("All");
  const [selected, setSelected] = useState<Project | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [copied, setCopied] = useState(false);
  const { scrollYProgress } = useScroll();
  const heroY = useTransform(scrollYProgress, [0, .3], [0, 90]);
  const heroOpacity = useTransform(scrollYProgress, [0, .24], [1, .25]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const visibleProjects = projects.filter(p => activeFilter === "All" || p.category === activeFilter);
  const nav = [{ label: "Work", href: "#work" }, { label: "Products", href: "#products" }, { label: "Capabilities", href: "#capabilities" }, { label: "About", href: "#about" }];

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText("ariyanahmed@gmail.com");
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch { window.location.href = "mailto:ariyanahmed@gmail.com"; }
  }

  return <main>
    <motion.div className="reading-progress" style={{ scaleX: scrollYProgress, transformOrigin: "0%" }} />
    <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}>
      <a className="brand" href="#top" aria-label="Ariyan Ahmed home"><span className="brand-mark">A<span>.</span></span><span className="brand-name">ARIYAN AHMED<small>DESIGN × CODE × SYSTEMS</small></span></a>
      <nav className="desktop-nav">{nav.map(n => <a key={n.href} href={n.href}>{n.label}</a>)}</nav>
      <div className="header-actions"><span className="availability"><i/> OPEN TO OPPORTUNITIES</span><a className="header-contact" href="#contact">Let’s talk <ArrowUpRight size={15}/></a><button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close menu" : "Open menu"}>{menuOpen ? <X/> : <Menu/>}</button></div>
      <AnimatePresence>{menuOpen && <motion.nav className="mobile-nav" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}>{nav.map(n => <a key={n.href} href={n.href} onClick={() => setMenuOpen(false)}>{n.label}<ArrowUpRight size={16}/></a>)}<a href="#contact" onClick={() => setMenuOpen(false)}>Contact<ArrowUpRight size={16}/></a></motion.nav>}</AnimatePresence>
    </header>

    <section className="hero section-wrap" id="top">
      <div className="hero-noise" />
      <motion.div className="hero-copy" style={{ y: heroY, opacity: heroOpacity }}>
        <Reveal><div className="eyebrow"><span className="eyebrow-line"/> INDEPENDENT DESIGNER & DEVELOPER <span className="eyebrow-muted">/ LONDON, UK</span></div></Reveal>
        <Reveal delay={.08}><h1>I make digital<br/><span className="text-gradient">things feel</span> <em>alive.</em></h1></Reveal>
        <Reveal delay={.16}><p className="hero-description">Game designer. Developer. Digital creator. I connect <strong>playful ideas</strong>, thoughtful interfaces and hands-on technology to build experiences that work beautifully — and feel different.</p></Reveal>
        <Reveal delay={.24}><div className="hero-ctas"><a className="button button-primary" href="#work">Explore my work <ArrowDownRight size={17}/></a><a className="button button-quiet" href="#about">A little about me <ArrowRight size={16}/></a></div></Reveal>
        <Reveal delay={.32}><div className="hero-footnote"><span className="scroll-cue"><MousePointer2 size={14}/></span><span>SCROLL TO EXPLORE</span><span className="hero-footline"/></div></Reveal>
      </motion.div>
      <div className="hero-art" aria-label="Abstract digital landscape illustration">
        <motion.div className="hero-orb orb-large" animate={{ y: [0, -16, 0], rotate: [0, 5, 0] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }} />
        <motion.div className="hero-orb orb-small" animate={{ y: [0, 12, 0], x: [0, 8, 0] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }} />
        <div className="hero-ring ring-one"/><div className="hero-ring ring-two"/><div className="hero-ring ring-three"/>
        <div className="hero-cross cross-one">+</div><div className="hero-cross cross-two">+</div><div className="hero-cross cross-three">+</div>
        <div className="hero-coordinate">51°30'26.4"N<br/>00°07'39.6"W</div>
        <div className="hero-art-caption"><span>FIG. 001</span><span>IDEAS → INTERACTION → IMPACT</span></div>
        <motion.div className="floating-chip chip-top" animate={{ y: [0, -6, 0] }} transition={{ duration: 4, repeat: Infinity }}><span className="chip-icon"><Braces size={16}/></span><span><b>Creative code</b><small>Build / iterate / refine</small></span></motion.div>
        <motion.div className="floating-chip chip-bottom" animate={{ y: [0, 7, 0] }} transition={{ duration: 5, repeat: Infinity }}><span className="chip-icon chip-purple"><Sparkles size={16}/></span><span><b>Experience first</b><small>Design with intention</small></span></motion.div>
      </div>
      <div className="hero-side-label">DESIGNING AT THE INTERSECTION <span>↘</span></div>
    </section>

    <section className="ticker" aria-label="Areas of work"><div className="ticker-track">{Array.from({length: 2}).map((_, i) => <div className="ticker-group" key={i}><span>GAME DESIGN</span><Asterisk/><span>DIGITAL PRODUCTS</span><Asterisk/><span>INTERACTIVE WORLDS</span><Asterisk/><span>HARDWARE & SYSTEMS</span><Asterisk/><span>UI / UX</span><Asterisk/></div>)}</div></section>

    <section className="work-section section-pad" id="work">
      <div className="section-heading"><Reveal><div className="eyebrow"><span className="eyebrow-line"/> 01 / SELECTED WORK</div><h2>Different disciplines.<br/><span className="heading-muted">One curious mind.</span></h2></Reveal><Reveal delay={.12}><p className="section-intro">A selection of things I’ve designed, built, tested and learned from — from playable systems to useful digital products.</p></Reveal></div>
      <div className="filter-row" role="group" aria-label="Filter projects">{filters.map(f => <button key={f} className={`filter-chip ${activeFilter === f ? "active" : ""}`} onClick={() => setActiveFilter(f)}>{f}{activeFilter === f && <motion.span layoutId="filter-dot" className="filter-dot"/>}</button>)}</div>
      <motion.div layout className="project-grid">
        <AnimatePresence mode="popLayout">{visibleProjects.map((p, i) => <motion.article layout key={p.number} className="project-card" initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: .97 }} transition={{ duration: .35, delay: i * .035 }}>
          <button className="project-open" onClick={() => setSelected(p)} aria-label={`Open ${p.title} case study`}><ProjectVisual kind={p.visual}/><div className="project-card-body"><div className="project-meta"><span>{p.number} / {p.type}</span><span className="project-status">{p.status}</span></div><div className="project-title-row"><h3>{p.title}</h3><span className="project-arrow"><ArrowUpRight size={18}/></span></div><p>{p.summary}</p><div className="tag-row">{p.tags.map(tag => <span key={tag}>{tag}</span>)}</div></div></button>
        </motion.article>)}</AnimatePresence>
      </motion.div>
      <div className="work-bottom"><span>SHOWING {visibleProjects.length.toString().padStart(2, "0")} PROJECTS</span><span className="muted-note">More work and case studies coming into focus.</span></div>
    </section>

    <section className="capabilities-section section-pad" id="capabilities">
      <div className="section-heading"><Reveal><div className="eyebrow"><span className="eyebrow-line"/> 02 / CAPABILITIES</div><h2>Curious by nature.<br/><span className="heading-muted">Technical by practice.</span></h2></Reveal><Reveal delay={.1}><p className="section-intro">I like understanding how the whole thing works — the experience, the code beneath it and the hardware it runs on.</p></Reveal></div>
      <div className="capability-grid">{skills.map((s, i) => <Reveal key={s.title} delay={i * .06} className="capability-wrap"><article className="capability-card"><div className="capability-top"><span className="capability-icon"><s.icon size={20}/></span><span className="capability-index">0{i + 1}</span></div><h3>{s.title}</h3><p>{s.subtitle}</p><div className="skill-list">{s.items.map(item => <span key={item}>{item}</span>)}</div><div className="capability-bottom"><span>CORE PRACTICE</span><ArrowUpRight size={15}/></div></article></Reveal>)}</div>
      <div className="capabilities-note"><Zap size={16}/><p><strong>My approach:</strong> connect design thinking with practical implementation, prototype early, test assumptions and keep learning across disciplines.</p></div>
    </section>

    <section className="products-section section-pad" id="products">
      <div className="products-banner"><div className="products-banner-bg"/><div className="products-banner-content"><Reveal><div className="eyebrow"><span className="eyebrow-line"/> 03 / BEYOND THE SCREEN</div><h2>Built for curiosity.<br/><span className="text-gradient">Made to be useful.</span></h2><p>Not everything I build fits neatly into one category. I’m interested in the systems, tools and physical setups that make better experiences possible.</p><a className="button button-primary" href="#contact">Have a project in mind? <ArrowUpRight size={16}/></a></Reveal></div><div className="products-orbit"><div className="product-orbit-ring ring-a"/><div className="product-orbit-ring ring-b"/><div className="product-orbit-ring ring-c"/><div className="product-orbit-core"><Monitor size={28}/><span>MAKE / TEST / REPEAT</span></div><span className="orbit-node node-a"><Cpu size={17}/></span><span className="orbit-node node-b"><Code2 size={17}/></span><span className="orbit-node node-c"><Gamepad2 size={17}/></span></div></div>
      <div className="product-pillars"><Reveal><div className="pillar"><span>01</span><h3>Digital products</h3><p>Websites, interfaces and tools that help people get things done.</p><span className="pillar-link">DESIGN + ENGINEERING <ArrowUpRight size={14}/></span></div></Reveal><Reveal delay={.08}><div className="pillar"><span>02</span><h3>Hardware & setups</h3><p>PC building, device ecosystems and the practical details behind a reliable setup.</p><span className="pillar-link">BUILD + TROUBLESHOOT <ArrowUpRight size={14}/></span></div></Reveal><Reveal delay={.16}><div className="pillar"><span>03</span><h3>Experiments</h3><p>Small prototypes, immersive technology and ideas worth exploring hands-on.</p><span className="pillar-link">PROTOTYPE + LEARN <ArrowUpRight size={14}/></span></div></Reveal></div>
    </section>

    <section className="about-section section-pad" id="about">
      <div className="about-left"><Reveal><div className="eyebrow"><span className="eyebrow-line"/> 04 / A LITTLE CONTEXT</div><h2>Design is how<br/>it <span className="text-gradient">works</span> and<br/>how it <em>feels.</em></h2></Reveal></div>
      <div className="about-right"><Reveal delay={.12}><p className="about-lead">I’m Ariyan Ahmed — a game development graduate and multidisciplinary digital creator based in the UK.</p><p>My work moves between game design, web development, interface design and immersive experiences. I enjoy turning a fuzzy idea into something people can actually use, play with or experience.</p><p>I’m equally interested in the details: how an interaction feels, why a system behaves the way it does, and what can be improved through thoughtful iteration.</p><div className="about-facts"><div><span>BASED IN</span><b>London, UK</b></div><div><span>BACKGROUND</span><b>Games Development</b></div><div><span>INTERESTS</span><b>Design × Code × Systems</b></div></div><a className="text-link" href="https://www.linkedin.com/" target="_blank" rel="noreferrer">Connect professionally <ArrowUpRight size={16}/><span className="placeholder-label">Replace with your LinkedIn profile URL</span></a></Reveal></div>
    </section>

    <section className="contact-section section-pad" id="contact"><div className="contact-glow"/><Reveal><div className="eyebrow"><span className="eyebrow-line"/> 05 / START A CONVERSATION</div><h2>Have a good<br/><span className="text-gradient">problem to solve?</span></h2><p className="contact-description">I’m interested in thoughtful collaborations, interesting challenges and projects that bring design and technology together.</p><div className="contact-actions"><a className="button button-primary button-large" href="mailto:ariyanahmed@gmail.com?subject=Let's%20work%20together">Tell me about it <ArrowUpRight size={17}/></a><button className="button button-outline button-large" onClick={copyEmail}>{copied ? <Check size={16}/> : <Mail size={16}/>} {copied ? "Email copied" : "Copy email"}</button></div><div className="contact-email">ARIYANAHMED@GMAIL.COM <span>↗</span></div></Reveal></section>

    <footer className="site-footer"><a className="footer-brand" href="#top"><span className="brand-mark">A<span>.</span></span> ARIYAN AHMED</a><span className="footer-middle">DESIGNED WITH INTENTION. BUILT WITH CURIOSITY.</span><div className="footer-right"><span>© {new Date().getFullYear()} ARIYAN AHMED</span><a href="#top" aria-label="Back to top"><ArrowDown className="back-top-icon" size={16}/></a></div></footer>

    <AnimatePresence>{selected && <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={e => { if (e.target === e.currentTarget) setSelected(null); }}><motion.div className="case-modal" role="dialog" aria-modal="true" aria-label={`${selected.title} case study`} initial={{ opacity: 0, y: 30, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: .98 }} transition={{ duration: .28 }}><button className="modal-close" onClick={() => setSelected(null)} aria-label="Close case study"><X size={20}/></button><ProjectVisual kind={selected.visual}/><div className="case-content"><div className="eyebrow"><span className="eyebrow-line"/> CASE STUDY / {selected.number}</div><h2>{selected.title}</h2><p className="case-summary">{selected.summary}</p><div className="case-tags">{selected.tags.map(t => <span key={t}>{t}</span>)}</div><div className="case-detail-grid"><div><span>MY ROLE</span><p>{selected.role}</p></div><div><span>THE CHALLENGE</span><p>{selected.challenge}</p></div><div><span>THE APPROACH</span><p>{selected.approach}</p></div><div><span>OUTCOME / NEXT STEP</span><p>{selected.outcome}</p></div></div><div className="case-footer"><span>PROJECT DETAILS TO BE VERIFIED / EXPANDED</span><a href="#contact" onClick={() => setSelected(null)}>Discuss a similar project <ArrowUpRight size={15}/></a></div></div></motion.div></motion.div>}</AnimatePresence>
  </main>;
}
